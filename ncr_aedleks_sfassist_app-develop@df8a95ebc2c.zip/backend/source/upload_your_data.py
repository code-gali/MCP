from fastapi import FastAPI, File, UploadFile, HTTPException
import pandas as pd
import os
import io
import tempfile
import mammoth
import PyPDF2
import uvicorn

def process_csv(file, conn):
    """Process and upload CSV files to Snowflake."""
    try:
        fl_nm = file.filename.split(".")[0]
        content = file.file.read()
        df = pd.read_csv(io.StringIO(content.decode("utf-8")))
        df_header = list(df.columns)

        ddl_columns = ', '.join([f"{col} VARCHAR" for col in df_header])
        create_stage_nm = f"CREATE OR REPLACE STAGE POC_SPC_SNOWPARK_DB.hedis_schema.{fl_nm}"
        create_table_nm = f"CREATE OR REPLACE TABLE POC_SPC_SNOWPARK_DB.hedis_schema.{fl_nm} ({ddl_columns})"
        print(create_stage_nm)
        print(create_table_nm)

        temp_file = tempfile.NamedTemporaryFile(suffix=".csv", delete=False)
        temp_file.write(content)
        temp_file.flush()
        temp_file.close()

        cs = conn.cursor()
        cs.execute(create_stage_nm)
        cs.execute(create_table_nm)

        sfstatement = f"PUT file://{temp_file.name} @POC_SPC_SNOWPARK_DB.hedis_schema.{fl_nm}"
        cs.execute(sfstatement)

        copy_into_stmt = f"""
            COPY INTO POC_SPC_SNOWPARK_DB.hedis_schema.{fl_nm}
            FROM @POC_SPC_SNOWPARK_DB.hedis_schema.{fl_nm}
            FILE_FORMAT = (TYPE=CSV, SKIP_HEADER=1, FIELD_DELIMITER=',', TRIM_SPACE=TRUE, FIELD_OPTIONALLY_ENCLOSED_BY='"', REPLACE_INVALID_CHARACTERS=TRUE, DATE_FORMAT=AUTO, TIME_FORMAT=AUTO, TIMESTAMP_FORMAT=AUTO) ON_ERROR=ABORT_STATEMENT;
        """
        cs.execute(copy_into_stmt)

        conn.commit()
        cs.close()
        os.remove(temp_file.name)

        return {"message": f"CSV data successfully loaded into table '{fl_nm}'"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

async def process_pdf_or_docx_or_txt(file, conn,app_nm):
    """Process and upload PDF, DOCX, or TXT files to Snowflake."""
    try:
        fl_nm = file.filename.split(".")[0].replace(" ","_").replace("-","_").replace(".","_")
        content = file.file.read()
        dataframes = []

        if file.filename.endswith(".docx"):
            with tempfile.NamedTemporaryFile(delete=False, suffix=".docx") as temp_file:
                temp_file.write(content)
                temp_file.flush()
                temp_file.close()  # Ensure the file is closed before accessing it
                with open(temp_file.name, "rb") as docx_file:
                    result = mammoth.convert_to_markdown(docx_file)
                    documents = result.value

                # Create a single-row DataFrame for the DOCX file
                df = pd.DataFrame([[file.filename, 1, documents]], columns=["file_name", "page_number", "raw_data"])
                dataframes.append(df)
                os.remove(temp_file.name)  # Delete the temporary file after processing

        elif file.filename.endswith(".pdf"):
            with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as temp_file:
                temp_file.write(content)
                temp_file.flush()
                temp_file.close()  # Ensure the file is closed before accessing it
                pdf_reader = PyPDF2.PdfReader(temp_file.name)

                for page_num in range(len(pdf_reader.pages)):
                    page = pdf_reader.pages[page_num]
                    page_text = page.extract_text()

                    # Create a DataFrame for each page
                    df = pd.DataFrame([[file.filename, page_num + 1, page_text]], columns=["file_name", "page_number", "raw_data"])
                    dataframes.append(df)

                os.remove(temp_file.name)  # Delete the temporary file after processing

        elif file.filename.endswith(".txt"):
            with tempfile.NamedTemporaryFile(delete=False, suffix=".txt") as temp_file:
                temp_file.write(content)
                temp_file.flush()
                temp_file.close()  # Ensure the file is closed before accessing it
                with open(temp_file.name, "r", encoding="utf-8") as txt_file:
                    text_content = txt_file.read()

                # Create a single-row DataFrame for the TXT file
                df = pd.DataFrame([[file.filename, 1, text_content]], columns=["file_name", "page_number", "raw_data"])
                dataframes.append(df)
                os.remove(temp_file.name)  # Delete the temporary file after processing

        # Combine all DataFrames into one
        final_df = pd.concat(dataframes, ignore_index=True)


        # Check if the table exists in Snowflake
        check_table_query = f"""
            SELECT COUNT(*)
            FROM POC_SPC_SNOWPARK_DB.INFORMATION_SCHEMA.TABLES
            WHERE TABLE_SCHEMA = 'HEDIS_SCHEMA'
            AND TABLE_NAME = '{app_nm.upper()}'
        """
        cs = conn.cursor()
        cs.execute(check_table_query)
        table_exists = cs.fetchone()[0] > 0
        print("Table Name", table_exists)

        # Create the table if it does not exist
        if not table_exists:
            create_table_nm = f"""
                CREATE OR REPLACE TABLE POC_SPC_SNOWPARK_DB.hedis_schema.{app_nm} (
                    FILE_NAME VARCHAR(100),
                    PAGE_NUMBER VARCHAR(10),
                    RAW_DATA VARCHAR(16777216) COLLATE 'utf8'
                )
            """
            print(f"Creating table: {create_table_nm}")
            cs.execute(create_table_nm)
            

        # Prepare data for bulk insert
        values = []
        for i, row in final_df.iterrows():
            file_name = row['file_name'].replace("'", "\\'")
            file_name = file_name.split("\\")[-1]
            page_number = row['page_number']
            raw_data = row['raw_data'].replace("'", "\\'")
            values.append(f"('{file_name}', {page_number}, '{raw_data}')")

        # Construct a single INSERT statement
        if values:
            insert_query = f"""
                INSERT INTO POC_SPC_SNOWPARK_DB.hedis_schema.{app_nm} (file_name, page_number, raw_data)
                VALUES {', '.join(values)}
            """
            create_search_service = f"""
                CREATE OR REPLACE CORTEX SEARCH SERVICE POC_SPC_SNOWPARK_DB.Hedis_Schema.{app_nm}
                ON RAW_DATA
                ATTRIBUTES FILE_NAME
                WAREHOUSE = POC_SPC_SNOWPARK_WH
                TARGET_LAG = '1 hour'
                AS (
                SELECT
                    RAW_DATA, FILE_NAME
                FROM POC_SPC_SNOWPARK_DB.Hedis_Schema.{app_nm}
                )
            """
            try:
                cs.execute(insert_query)
                print(f"Successfully inserted data for file: {app_nm}")
                cs.execute(create_search_service)
                print(f"Successfully created search service for file: {app_nm}")
            except Exception as e:
                print(f"Snowflake Error for file {app_nm}: {e}")
            finally:
                cs.close()

        conn.commit()

        return {"message": f"File '{app_nm}' successfully loaded into table"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    

async def read_file_extract(files,sf_conn,app_nm):
    """Read the file and extract its content."""
    results = []  # Collect results for all files
    for file in files:
        try:
            print(f"Processing file: {file.filename}")
            if file.filename.endswith(".csv"):
                result = await process_csv(file, sf_conn)  
            elif file.filename.endswith(".pdf") or file.filename.endswith(".docx") or file.filename.endswith(".txt"):
                result = await process_pdf_or_docx_or_txt(file, sf_conn,app_nm)  # Await the async function
            else:
                raise HTTPException(status_code=400, detail=f"Unsupported file type: {file.filename}. Only CSV, PDF, TXT, and DOCX are supported.")
            results.append({"file": file.filename, "status": "success", "message": result["message"]})
        except Exception as e:
            print(f"Error processing file {file.filename}: {e}")
            results.append({"file": file.filename, "status": "error", "message": str(e)})

    return {"results": results}