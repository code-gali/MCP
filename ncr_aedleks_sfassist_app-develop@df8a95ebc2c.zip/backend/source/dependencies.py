from functools import lru_cache
from fastapi import (
    APIRouter,
    Depends,
    Query,
    HTTPException,
    status
    
)
from typing import Annotated
from typing import List

from config import GenAiEnvSettings
from logging import Logger
import logging 

from ReduceReuseRecycleGENAI import load_log_config, get_timestamp
from ReduceReuseRecycleGENAI.api import get_api_key
from ReduceReuseRecycleGENAI.snowflake import snowflake_conn,get_sf_database_name
from functools import partial
from models import (
    GenAiCortexAudit,
     CompleteQryModel,
     SearchModel,
     AnalystModel
)
import snowflake.connector
import json
import pandas as pd


#Get the required configuration loaded
@lru_cache
def get_config() -> GenAiEnvSettings:
    return GenAiEnvSettings()

def get_logger() -> Logger: 
    return logging.getLogger(__name__)

def get_load_timestamp() -> Logger: 
    utc_string, est_string, est2_string = get_timestamp()
    #est_string = "2025-03-11"
    return est_string

def get_db_name() -> Logger: 
    return get_sf_database_name()

class ValidApiKey: 
    def __init__(self):
        self.config = get_config()
        self.logger = get_logger() 
        self.func_apikey = partial(
           get_api_key,
               self.logger,
               self.config.env,
               self.config.region_name,
           )
    
    def __call__(
            self,
            api_key: str,
            aplctn_cd: str,
            app_id: str
        ) -> bool:
        try:
            extracted_api_key = self.func_apikey(aplctn_cd, app_id)
            return extracted_api_key['api_key'] == api_key
        except Exception as e:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED,
                                detail = str(e))
class SnowFlakeConnector: 
    conn = None
    conn_key=None
    sf_conn_dict={}
    def __init__(self,aplctn_cd,sf_prefix):
        self.config = get_config()
        self.logger = get_logger()
        self.aplctn_cd = aplctn_cd
        self.sf_prefix = sf_prefix

        SnowFlakeConnector.conn =  snowflake_conn(
           self.logger, 
           aplctn_cd=aplctn_cd,
           env=self.config.env,
           region_name=self.config.region_name, 
           warehouse_size_suffix=self.config.pltfrm_lvl_warehouse_size_suffix,
           prefix = self.sf_prefix
        )

    @classmethod
    def get_conn(cls,aplctn_cd,sf_prefix,session_id):
        key = (aplctn_cd,sf_prefix,session_id)       
        if key in cls.sf_conn_dict and cls.sf_conn_dict[key].is_valid():
            print(f'The connection already exists for Application =\'{aplctn_cd}\' and Request ID =\'{session_id}\' : {cls.sf_conn_dict[key]}')
            return cls.sf_conn_dict[key] 
        else:
            cls(aplctn_cd,sf_prefix)
            cls.sf_conn_dict[key]=cls.conn
            print(f"Snowflake Connection established successfully for application") 
            return cls.conn         

def log_response(audit_rec:GenAiCortexAudit,query_id: list,response_text: list,fdbck_id: list,session_id: str):
    config = get_config()
    sf_conn = SnowFlakeConnector.get_conn(
            config.pltfrm_aplctn_cd,
            config.pltfrm_lvl_prefix,
            session_id=session_id
        )
    
    audit_dict = audit_rec.model_dump()
    audit_items = audit_dict.items()
    #Build Insert query 
    insert_sql = \
    """
    INSERT 
    INTO {db_name}.{schema}.{table} 
    ({fields}) 
    values ({values})
    """.format(
        db_name = config.pltfrm_lvl_sf_db_nm,
        schema= config.pltfrm_lvl_sf_schma_nm,
        table=config.job_audit_tbl,
        fields=",".join([rec for rec,_ in audit_items ] + ['qry_id','rspns_txt','feedbk_id']),
        values=",".join(["'" + rec +"'" for _,rec in audit_items] + ["'" + query_id[0] + "'","'" + "".join(response_text).replace("'","\\'") + "'","'" + fdbck_id[0] + "'"])
    )

    plt_cs = sf_conn.cursor()
    plt_cs.execute(insert_sql)
    plt_cs.close()
    return "query executed successfully"

def update_log_response(fdbck_id, feedbk_actn_txt=None, feedbk_cmnt_txt=None, session_id=None):
    """
    Update the audit table in Snowflake with feedback action text, feedback comment text, or both.
    """
    config = get_config()
    plt_sf_conn = SnowFlakeConnector.get_conn(
        config.pltfrm_aplctn_cd,
        config.pltfrm_lvl_prefix,
        session_id=session_id
    )

    # Get the current timestamp for feedback update
    feedbk_updt_dtm = get_load_timestamp()

    # Build the update query dynamically based on provided parameters
    update_fields = []
    if feedbk_cmnt_txt is not None:
        update_fields.append(f"feedbk_cmnt_txt = '{feedbk_cmnt_txt}'")
    if feedbk_actn_txt is not None:
        update_fields.append(f"feedbk_actn_txt = '{feedbk_actn_txt}'")
    update_fields.append(f"feedbk_updt_dtm = '{feedbk_updt_dtm}'")

    # Combine the update fields into a single query
    update_query = f"""
        UPDATE {config.pltfrm_lvl_sf_db_nm}.{config.pltfrm_lvl_sf_schma_nm}.{config.job_audit_tbl}
        SET {', '.join(update_fields)}
        WHERE feedbk_id = '{fdbck_id}'
    """

    # Execute the update query
    try:
        cs_plt = plt_sf_conn.cursor()
        cs_plt.execute(update_query)
        cs_plt.close()
        print("Record updated successfully")
        return "Audit Table updated successfully"
    except Exception as e:
        print(f"Error updating record: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="An error occurred while updating the audit table."
        )


def get_cortex_search_details(search_input: SearchModel
    ):
    sf_conn = SnowFlakeConnector.get_conn(
    search_input.aplctn_cd,
    search_input.app_lvl_prefix,
    search_input.session_id)

    query = f"SHOW CORTEX SEARCH SERVICES in SCHEMA {search_input.database_nm}.{search_input.schema_nm};"
    cs = sf_conn.cursor()
    q_exist_table = query
    df_lst = cs.execute(q_exist_table).fetchall()
    search_names  = [sublist[1] for sublist in df_lst]
    return search_names

def get_cortex_analyst_details(analyst_input: AnalystModel
    ):
    sf_conn = SnowFlakeConnector.get_conn(
    analyst_input.aplctn_cd,
    analyst_input.app_lvl_prefix,
    analyst_input.session_id)
    cs = sf_conn.cursor()

    #database_nm = "DOC_AI_DB"
    #schema_nm= "HEDIS_SCHEMA"
    
    stage_show = f"SHOW STAGES in SCHEMA {analyst_input.database_nm}.{analyst_input.schema_nm};"
    # Get list of all stage names
    df_stg_lst = cs.execute(stage_show).fetchall()
    stage_names  = [sublist[1] for sublist in df_stg_lst]
    print(stage_names)
    semantic_models = []

    for stage_name in stage_names:
        # Quote stage name if it contains special characters
        #formatted_stage_name = f'"{stage_name}"' if ' ' in stage_name or '(' in stage_name else stage_name
        list_query = f"LIST @{analyst_input.database_nm}.{analyst_input.schema_nm}.{stage_name};"
        print(list_query)
        
        try:
            df_stg_files_lst = cs.execute(list_query).fetchall()
        except Exception as e:
            print(f"Error listing files in stage {stage_name}: {e}")
            continue
        print(df_stg_files_lst)
        # Extract .yaml files
        for sublist in df_stg_files_lst:
            file_path = sublist[0]
            if file_path.endswith('.yaml') or file_path.endswith('.yaml.gz'):
                file_name = file_path.split('/')[-1]
                semantic_models.append(file_name)

    cs.close()
    return semantic_models


def get_load_vector_data(query):
    sf_conn = SnowFlakeConnector.get_conn(
                query.aplctn_cd,
                query.app_lvl_prefix,
                query.session_id,
        )
    app_cs = sf_conn.cursor()
    raw_text = json.loads(query.raw_data)
    df_raw = pd.DataFrame(raw_text)
    print(df_raw)
    # Build insert query
    insert_query = f"insert into {query.database_nm}.{query.schema_nm}.{query.tbl_nm} "
    row_values = []
    # Process each row
    for i, row in df_raw.iterrows():
        raw_data = str(row['raw_data']).replace("'", "\\'")
        row_value = (
            f"SELECT '{raw_data}', "
            f"snowflake.cortex.{query.vector_embed_type}('{query.vector_embed_model}', '{raw_data}')"
        )
        row_values.append(row_value)

        # Combine queries
        select_query = " UNION ALL ".join(row_values)
        final_query = f"{insert_query} {select_query}"

    print(final_query)
    
    cur_res = app_cs.execute(final_query)
    return f"Successfully loaded vector data into Snowflake table {query.tbl_nm}"
