from pydantic_settings import (
    BaseSettings
    ,SettingsConfigDict
)
class GcnAiEnvironment(BaseSettings): 
    dev_host: str
    sit_host: str
    uat_host: str
    preprod_host: str 
    prod_host: str  

class Gt2sAiEnvironment(BaseSettings): 
    dev_host: str
    sit_host: str
    uat_host: str
    preprod_host: str 
    prod_host: str  

class GcAgentAiEnvironment(BaseSettings): 
    dev_host: str
    sit_host: str
    uat_host: str
    preprod_host: str 
    prod_host: str  


class GenAiEnvSettings(BaseSettings):

    model_config = SettingsConfigDict(env_file=("config.env","config.prod.env"),env_prefix="GENAI_",env_nested_delimiter="__", nested_model_default_partial_update=True) 
    
    app_lvl_sf_schma_nm: str  = "SUPPORTCBT_STG"
    app_lvl_warehouse_size_suffix: str = "" 
    pltfrm_aplctn_cd: str = "edagnai"
    pltfrm_lvl_sf_db_nm: str = "D01_EDA_GENAI"
    pltfrm_lvl_sf_schma_nm:str =  "SUPPORTCBT"
    pltfrm_lvl_prefix:str = "supportcbt_dml"
    pltfrm_lvl_warehouse_size_suffix: str = "" 
    env: str = "dev"
    region_name: str = "us-east-2"
    job_audit_tbl: str ="LLM_AUDT"
    cortex_shortest_func: str ="vector_l2_distance"
    cortex_embed_func: str = "e5-base-v2"
    cortex_model_id: str = "llama3.1-70b-elevance"
    cortex_context: str = "you are powerful assistant in providing accurate answers"
    COMPLETE: GcnAiEnvironment
    TXT2SQL: Gt2sAiEnvironment
    AGENT: GcAgentAiEnvironment
