#This script has been created to just capture the code base that has been commented; this script will eventually be scrapped 
#messages_json = query.prompt
#prompt = query.prompt 
# if isinstance(messages_json, list) and len(messages_json) > 0:
#     for elm in range(len(messages_json) -1, -1,-1):
#         if messages_json[elm]['role'] == 'user':
#             prompt = messages_json[elm]['content']
#             break 

#As the model has been standardized as list; we need not to verify for the type; 

#if isinstance(messages_json, str):
#    prompt_last_msg = [{"role": "user", "content": messages_json}]
#    messages_json = prompt_last_msg  

#pltfrm_sf_conn = snowflake_connect(
#        config.pltfrm_aplctn_cd, 
#        query.session_id,
#        config.pltfrm_lvl_warehouse_size_suffix,
#        config.pltfrm_lvl_prefix,
#        logger,
#        config.env,
#        config.region_name,)

#SnowFlake connection 
# __sf_conn_dict = {}
# def snowflake_connect(aplctn_cd, session_id,wh_size,sf_prefix,logger,env,region_nm):
#     sf_conn_dict_key = (aplctn_cd, session_id)
#     if sf_conn_dict_key in __sf_conn_dict.keys() and not __sf_conn_dict[sf_conn_dict_key].is_closed():
#         print(f'The connection already exists for Application =\'{aplctn_cd}\' and Request ID =\'{session_id}\' : {__sf_conn_dict[sf_conn_dict_key]}')
#         return __sf_conn_dict[sf_conn_dict_key]
#     else:
#         conn = snowflake_conn(logger, aplctn_cd=aplctn_cd, env=env, region_name=region_nm, warehouse_size_suffix=wh_size,prefix = sf_prefix)
#         print(f"Snowflake Connection established successfully")
#         __sf_conn_dict[sf_conn_dict_key] = conn
#         return conn
