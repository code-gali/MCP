from pydantic import (
    BaseModel,
    Field,
    HttpUrl,
    model_validator,
)
from typing import (
    Optional,
    Union,
    List
)
import uuid

class Prompt(BaseModel): 
    role: str = Field('',description="Role from the chart session")
    content: str = Field('',description="Message Request or Response")

class AllPrompts(BaseModel):
    messages: List[Prompt] = Field(...,description="All messages from session")
 
class CompleteQryModel(BaseModel):
    aplctn_cd: str = Field("edagnai",description="Application code assigned, example codes are 'aedl'")
    app_id: str = Field('edadip',description="Id assigned to the application")
    api_key: Optional[str] = Field('78a799ea-a0f6-11ef-a0ce-15a449f7a8b0',description="Api key assigned to the application")
    method: str = Field("cortex",description="LLM Interface example Cortex")
    model: str = Field("llama3.1-70b",description="LLM Model to connect") 
    sys_msg: str = Field("You are powerful AI assistant in providing accurate answers always. Be Concise in providing answers based on context.")
    limit_convs: Optional[str] = Field("0")
    prompt: AllPrompts = Field(...,description="Prompt being used for the application")
    app_lvl_prefix: Optional[str] = Field("")
    user_id: Optional[str] = Field("")
    session_id: Optional[str] = Field(str(uuid.uuid4()))

    @model_validator(mode="after")
    def check_app_id(self):
        if not self.app_id:
            raise ValueError("Not a valid application id, provide valid application id") 
        return self
    
class GenAiCortexAudit(BaseModel):
    edl_load_dtm: str = Field("2025-03-11", description="EDL load datetime")
    edl_run_id: str = Field("0000", description="EDL run ID")
    edl_scrty_lvl_cd: str = Field("NA", description="EDL security level code")
    edl_lob_cd: str = Field("NA", description="EDL line of business code")
    srvc_type: str = Field("complete", description="Service type")
    aplctn_cd: str = Field('edagnai', description="Platform Application code from query")
    user_id: Optional[str] = Field(None, description="User ID from query")
    mdl_id: str = Field('', description="Model ID from query")
    cnvrstn_chat_lmt_txt: Optional[str] = Field(None, description="Conversation chat limit text from query")
    sesn_id: str = Field('', description="Session ID from query")
    prmpt_txt: str = Field('', description="Prompt text from query, escaped")
    tkn_cnt: str = Field("0", description="Token count")
    feedbk_actn_txt: str = Field("", description="Feedback action text")
    feedbk_cmnt_txt: str = Field("", description="Feedback comment text")
    feedbk_updt_dtm: str = Field("2025-03-11", description="Feedback update datetime")

class Txt2SqlModel(BaseModel):
    aplctn_cd: str = Field("edagnai",description="Application code assigned, example codes are 'aedl'")
    app_id: str = Field('edadip',description="Id assigned to the application")
    api_key: Optional[str] = Field('78a799ea-a0f6-11ef-a0ce-15a449f7a8b0',description="Api key assigned to the application")
    model: str = Field("llama3.1-70b",description="LLM Model to connect") 
    user_id: Optional[str] = Field('Analyst_User', description="User ID from query")
    cnvrstn_chat_lmt_txt: Optional[str] = Field('0', description="Conversation chat limit text from query")
    semantic_model: List[str] = Field([],description="Show list of yaml files") 
    prompt: AllPrompts = Field(...,description="Prompt being used for the application")
    app_lvl_prefix: Optional[str] = Field("")
    session_id: Optional[str] = Field(str(uuid.uuid4()))
    database_nm:str = Field('D01_EDA_GENAI',descriptioAgentModeln="Database name assigned to the application")
    schema_nm :str = Field('SUPPORTCBT',description="schema name assigned to the application")
    stage_nm: str = Field('',description="stage name assigned to the application")

class AgentModel(BaseModel):
    aplctn_cd: str = Field("edagnai",description="Application code assigned, example codes are 'aedl'")
    app_id: str = Field('edadip',description="Id assigned to the application")
    api_key: Optional[str] = Field('78a799ea-a0f6-11ef-a0ce-15a449f7a8b0',description="Api key assigned to the application")
    model: str = Field("llama3.1-70b",description="LLM Model to connect") 
    user_id: Optional[str] = Field('Agent_User', description="User ID from query")
    cnvrstn_chat_lmt_txt: Optional[str] = Field(None, description="Conversation chat limit text from query")
    semantic_model: List[str] = Field([],description="Show list of yaml files") 
    search_service: List[str] = Field([],description="Show list of Search Services") 
    search_limit: Optional[int] = Field("0")
    prompt: AllPrompts = Field(...,description="Prompt being used for the application")
    app_lvl_prefix: Optional[str] = Field("")
    session_id: Optional[str] = Field(str(uuid.uuid4()))
    database_nm:str = Field('D01_EDA_GENAI',description="Database name assigned to the application")
    schema_nm :str = Field('SUPPORTCBT',description="schema name assigned to the application")
    stage_nm: str = Field('',description="stage name assigned to the application")

class SqlExecModel(BaseModel):
    aplctn_cd: str = Field("edagnai",description="Application code assigned, example codes are 'aedl'")
    app_id: str = Field('edadip',description="Id assigned to the application")
    api_key: Optional[str] = Field('78a799ea-a0f6-11ef-a0ce-15a449f7a8b0',description="Api key assigned to the application")
    prompt: AllPrompts = Field(...,description="Prompt being used for the application")
    app_lvl_prefix: Optional[str] = Field("")
    session_id: Optional[str] = Field(str(uuid.uuid4()))
    exec_sql: str = Field("",description="SQL to execute")
    

class SearchModel(BaseModel):
    aplctn_cd: str = Field("edagnai",description="Application code assigned, example codes are 'aedl'")
    app_id: str = Field('edadip',description="Id assigned to the application")
    api_key: Optional[str] = Field('78a799ea-a0f6-11ef-a0ce-15a449f7a8b0',description="Api key assigned to the application")
    app_lvl_prefix: Optional[str] = Field("")
    session_id: Optional[str] = Field(str(uuid.uuid4()))
    database_nm:str = Field('D01_EDA_GENAI',description="Database name assigned to the application")
    schema_nm :str = Field('SUPPORTCBT',description="schema name assigned to the application")

class AnalystModel(BaseModel):
    aplctn_cd: str = Field("edagnai",description="Application code assigned, example codes are 'aedl'")
    app_id: str = Field('edadip',description="Id assigned to the application")
    api_key: Optional[str] = Field('78a799ea-a0f6-11ef-a0ce-15a449f7a8b0',description="Api key assigned to the application")
    app_lvl_prefix: Optional[str] = Field("")
    session_id: Optional[str] = Field(str(uuid.uuid4()))
    database_nm:str = Field('D01_EDA_GENAI',description="Database name assigned to the application")
    schema_nm :str = Field('SUPPORTCBT',description="schema name assigned to the application")
    stage_nm: str = Field('',description="stage name assigned to the application")

class LoadVectorModel(BaseModel):
    aplctn_cd: str = Field("edagnai",description="Application code assigned, example codes are 'aedl'")
    app_id: str = Field('edadip',description="Id assigned to the application")
    api_key: Optional[str] = Field('78a799ea-a0f6-11ef-a0ce-15a449f7a8b0',description="Api key assigned to the application")
    app_lvl_prefix: Optional[str] = Field("")
    session_id: Optional[str] = Field(str(uuid.uuid4()))
    database_nm:str = Field('D01_EDA_GENAI',description="Database name assigned to the application")
    schema_nm :str = Field('SUPPORTCBT',description="schema name assigned to the application")
    tbl_nm: str = Field('',description="Table name assigned to the application")
    tbl_rec_flg: str = Field('',description="Table Record Flag assigned to the application")
    vector_embed_type: str = Field('embed_text_768',description="Vector Embed function to use by application")
    vector_embed_model: str = Field('e5-base-v2',description="Vector Embed Model to use by application")
    raw_data: str = Field('',description="Raw Data or chunks of data created by application")

class UploadFileModel(BaseModel):
    aplctn_cd: str = Field('edagnai',description="Application code assigned, example codes are 'aedl'")
