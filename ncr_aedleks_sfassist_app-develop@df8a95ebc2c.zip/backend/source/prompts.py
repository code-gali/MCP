def fetch_last_n_jsons(history, user_message, assistant_response, limit_convs):
    """Add a user-assistant message pair to the conversation history with a pair limit"""
    
    # If limit_convs is 0, return an empty history (no conversation stored)
    if limit_convs == 0:
        return []

    # Create message pair
    message_pair = {
        'user': user_message,
        'assistant': assistant_response
    }

    # Add the pair to history
    history.append(message_pair)

    # If the number of pairs exceeds the limit, keep only the most recent pairs
    if len(history) > limit_convs:
        history = history[-limit_convs:]

    return history

def get_conv_response(messages_json, limit_convs=None):
    
    last_msg=messages_json[-1].model_dump()
   # Initialize empty conversation history
    conversation_history = []

    # Iterate over the messages in pairs
    for i in range(0, len(messages_json) - 1, 2):
        user_message = messages_json[i].content
        assistant_response = messages_json[i + 1].content
        conversation_history = fetch_last_n_jsons(
            conversation_history,
            user_message,
            assistant_response,
            limit_convs
        )
        #print_conversation(conversation_history)

    INITAL_PROMPT = f"""<|begin_of_text|><|start_header_id|>system<|end_header_id|>

    You are a helpful AI chat assistant with all capabilities.
    Below is the context supplied.{last_msg}
    <|eot_id|>
    """
    new_prompt_template=INITAL_PROMPT + " The chat history is as below \n" + str(conversation_history)
    print("new_prompt_template",new_prompt_template)
    return new_prompt_template
